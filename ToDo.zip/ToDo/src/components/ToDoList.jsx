import React, { useState, useEffect } from 'react';
import './TodoList.css';

function TodoList() {
  const [taskInput, setTaskInput] = useState('');
  const [taskList, setTaskList] = useState([]);
  const [selectedTasks, setSelectedTasks] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem('myTasks');
    if (saved) {
      setTaskList(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('myTasks', JSON.stringify(taskList));
  }, [taskList]);

  const handleAdd = () => {
    if (!taskInput.trim()) return;

    const newTask = {
      id: Date.now(),
      text: taskInput.trim(),
    };

    setTaskList([...taskList, newTask]);
    setTaskInput('');
  };

  const handleSelect = (taskId) => {
    if (selectedTasks.includes(taskId)) {
      setSelectedTasks(selectedTasks.filter(id => id !== taskId));
    } else {
      setSelectedTasks([...selectedTasks, taskId]);
    }
  };

  const handleDeleteSelected = () => {
    const remaining = taskList.filter(task => !selectedTasks.includes(task.id));
    setTaskList(remaining);
    setSelectedTasks([]);
  };

  return (
    <div className="todo-page">
      <div className="todo-card">
        <h1 className="main-title">To-Do List</h1>

        <div className="input-row">
          <input
            type="text"
            placeholder="Add a task..."
            value={taskInput}
            onChange={(e) => setTaskInput(e.target.value)}
            className="task-field"
          />
          <button onClick={handleAdd} className="btn add">Add</button>
          <button onClick={handleDeleteSelected} className="btn delete">Delete</button>
        </div>

        <ul className="task-list">
          {taskList.map((task) => (
            <li
              key={task.id}
              className={`task-item ${selectedTasks.includes(task.id) ? 'active' : ''}`}
            >
              <input
                type="checkbox"
                checked={selectedTasks.includes(task.id)}
                onChange={() => handleSelect(task.id)}
              />
              <span className="task-label">{task.text}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default TodoList;
