import React from 'react';
import TodoList from './components/ToDoList'; 

function App() {
  return (
    <div>
      <TodoList />
    </div>
  );
}

export default App;
